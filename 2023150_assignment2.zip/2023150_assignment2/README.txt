Generic Programming

1. List<T> is used in multiple classes (e.g., Course, Student) to manage collections of various types.
2. The Feedback class uses a generic type parameter, allowing for different types of feedback data.

Object Classes

1. Inheritance: The User class serves as a base for Student, Professor, and Admin classes.
2. Encapsulation: Each class (e.g., Course, Feedback, Complaint) manages its own data and operations.
3. Polymorphism: Methods like RegisterForCourses() and DropCourses() are implemented differently for Student and Professor classes.
4. Abstraction: interfaces like SystemInterface are used to define contracts for implementing classes.

Exception Handling

1. DropDeadlineException: Thrown when a course drop is attempted after the deadline which is set by Admin.
2. CourseFullException: Thrown when trying to enroll in a course which has reached its maximum capacity which is again set by the Professor.
3. InvalidLoginException: Thrown when there is authentication failure during login.

Steps to run on terminal :

Extract 2023150_assignment2
cd 2023150_assignment2
javac project/main/main.java 
java project/main/main.java

Steps to run on IntelliJ :

Extract 2023150_assignment2
Go inside 2023150_assignment2 folder
Go inside main
Run main.java