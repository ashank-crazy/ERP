package project.main;

import java.util.*;
import project.admin.Admin;
import project.models.*;
import project.professor.Professor;
import project.student.Student;
import project.ta.Ta;

public class main
{
    static ArrayList<Student> Students = new ArrayList<>();
    static ArrayList<Professor> Professors = new ArrayList<>();
    static ArrayList<Admin> Admins = new ArrayList<>();
    static ArrayList<Ta> Tas = new ArrayList<>();
    static HashMap<String, User> Users = new HashMap<>();

    public static void main(String[] args)
    {
        // to pre populate data
        initializeData();
        enrollStudentsInCourses();

        Scanner scanner = new Scanner(System.in);

        while(true)
        {
            mainmenu1();
            String select = scanner.nextLine();

            switch (select)
            {
                case "1":
                    mainmenu2();
                    loginmenu();
                    break;
                case "2":
                    mainmenu3();
                    signupmenu();
                    break;
                case "3":
                    System.out.println("\nSuccessfully exited");
                    return;
                default:
                    System.out.println("\nPlease choose a valid option");
                    break;
            }
        }
    }

    public static void initializeData()
    {
        // adding some default students/professors/admins
        Admin Default_admin = new Admin("Default_admin@iiitd.ac.in", "1234", "Admin");
        Professor Default_professor = new Professor("Default_professor@iiitd.ac.in", "1234", "Professor");
        Student Default_student = new Student("Default_student@iiitd.ac.in", "1234", "Student");
        Ta Default_ta = new Ta ("Default_ta@iiitd.ac.in","1234","Ta");

        Admin admin1 = new Admin("admin1@iiitd.ac.in", "1234", "Admin");
        Admin admin2 = new Admin("admin2@iiitd.ac.in", "1234", "Admin");
        Admin admin3 = new Admin("admin3@iiitd.ac.in", "1234", "Admin");

        Admins.add(admin1);
        Admins.add(admin2);
        Admins.add(admin3);

        Professor prof1 = new Professor("prof1@iiitd.ac.in", "1234", "Professor");
        Professor prof2 = new Professor("prof2@iiitd.ac.in", "1234", "Professor");
        Professor prof3 = new Professor("prof3@iiitd.ac.in", "1234", "Professor");

        Professors.add(prof1);
        Professors.add(prof2);
        Professors.add(prof3);

        Student student1 = new Student("student1@iiitd.ac.in", "1234", "Student");
        Student student2 = new Student("student2@iiitd.ac.in", "1234", "Student");
        Student student3 = new Student("student3@iiitd.ac.in", "1234", "Student");

        Students.add(student1);
        Students.add(student2);
        Students.add(student3);

        Ta ta1 = new Ta ("ta1@iiitd.ac.in", "1234", "Ta");
        Ta ta2 = new Ta ("ta2@iiitd.ac.in", "1234", "Ta");
        Ta ta3 = new Ta ("ta3@iiitd.ac.in", "1234", "Ta");

        Tas.add(ta1);
        Tas.add(ta2);
        Tas.add(ta3);

        Users.put(admin1.getEmail(), admin1);
        Users.put(admin2.getEmail(), admin2);
        Users.put(admin3.getEmail(), admin3);
        Users.put(student1.getEmail(), student1);
        Users.put(student2.getEmail(), student2);
        Users.put(student3.getEmail(), student3);
        Users.put(prof1.getEmail(), prof1);
        Users.put(prof2.getEmail(), prof2);
        Users.put(prof3.getEmail(), prof3);
        Users.put(ta1.getEmail(), ta1);
        Users.put(ta2.getEmail(), ta2);
        Users.put(ta3.getEmail(), ta3);
        Users.put(Default_admin.getEmail(), Default_admin);
        Users.put(Default_professor.getEmail(), Default_professor);
        Users.put(Default_student.getEmail(), Default_student);
        Users.put(Default_ta.getEmail(), Default_ta);

        Admins.add(Default_admin);
        Professors.add(Default_professor);
        Students.add(Default_student);
    }

    private static void enrollStudentsInCourses()
    {
        List<Course> exampleCourses = Coursecatalog.getCoursesForSemester(1);

        System.out.println("\nStarting Pre population");
        System.out.println();

        for (Student student : Students)
        {
            System.out.println(student.getEmail() + " is being enrolled in courses.");

            for (Course course : exampleCourses)
            {
                if (!student.isEnrolledInCourse(course.getCourseCode()))
                {
                    student.enrolled_courses.add(course);
                    student.credits += course.getCredits();
                    course.enrollStudent(student);
                    System.out.println(student.getEmail() + " successfully enrolled in " + course.getTitle());
                }
                else
                {
                    System.out.println(student.getEmail() + " is already enrolled in " + course.getTitle());
                }
            }
        }

        System.out.println("\nPre population completed");
    }

    public static void loginmenu()
    {
        try
        {
            Scanner scanner = new Scanner(System.in);
            String select = scanner.nextLine();

            switch (select)
            {
                case "1":
                    authenticate_user("Student");
                    break;
                case "2":
                    authenticate_user("Professor");
                    break;
                case "3":
                    authenticate_user("Admin");
                    break;
                case "4":
                    authenticate_user("Ta");
                    break;
                case "5":
                    return;
                default:
                    System.out.println("\nPlease choose a valid option");
                    break;
            }
        }
        catch (InvalidLoginException e)
        {
            System.out.println("Login failed: " + e.getMessage());
        }
        catch (Exception e)
        {
            System.out.println("Error 101 : Login menu " + e.getMessage());
        }
    }

    public static void signupmenu()
    {
        try
        {
            Scanner scanner = new Scanner(System.in);
            String select = scanner.nextLine();
            String email = "";
            String password = "";

            if (select.equals("1") || select.equals("2") || select.equals("3") || select.equals("4"))
            {
                System.out.println("\nEnter your college email id");
                email = scanner.nextLine();

                if (Users.containsKey(email))
                {
                    System.out.println("\nUser with this email already exists. Please try logging in");
                    return;
                }
                if (select.equals("1") || select.equals("2") || select.equals("4"))
                {
                    System.out.println("\nChoose your Password");
                    password = scanner.nextLine();
                }
            }

            switch (select)
            {
                case "1":
                    Student newStudent = new Student(email, password, "Student");
                    Students.add(newStudent);
                    Users.put(email, newStudent);
                    System.out.println("\nSignup Successful ! you may login now");
                    break;
                case "2":
                    Professor newProfessor = new Professor(email, password, "Professor");
                    Professors.add(newProfessor);
                    Users.put(email, newProfessor);
                    System.out.println("\nSignup Successful ! you may login now");
                    break;
                case "3":
                    System.out.println("\nThe password for admin is set by default");
                    Admin newAdmin = new Admin(email, "1234", "Admin");
                    Admins.add(newAdmin);
                    Users.put(email, newAdmin);
                    System.out.println("\nSignup Successful ! you may login now");
                    break;
                case "4":
                    Ta newTa = new Ta(email, password, "Ta");
                    Tas.add(newTa);
                    Users.put(email, newTa);
                    System.out.println("\nSignup Successful ! you may login now");
                    break;
                case "5":
                    return;
                default:
                    System.out.println("\nPlease choose a valid option");
                    break;
            }
        }
        catch (Exception e)
        {
            System.out.println("Error 101 : Signup menu " + e.getMessage());
        }
    }

    // to check whether email exists in directory and if it does then whether the entered password matches or not
    public static void authenticate_user(String userType) throws InvalidLoginException
    {
        try
        {
            Scanner scanner = new Scanner(System.in);
            int attempts = 5;

            while (attempts > 0)
            {
                System.out.println("\nEnter your email id (or type 'back' to go to the previous menu): ");
                String email = scanner.nextLine();

                if (email.equalsIgnoreCase("back"))
                    return;

                System.out.println("\nEnter your password: ");
                String password = scanner.nextLine();

                if (Users.containsKey(email))
                {
                    User user = Users.get(email);

                    if (user.authenticate(password, userType))
                    {
                        System.out.println("\nLogin Successful");

                        if (userType.equals("Student"))
                        {
                            Student verified_student = (Student) user;
                            handleStudentMenu(verified_student);
                        }
                        else if (userType.equals("Professor"))
                        {
                            Professor verified_professor = (Professor) user;
                            handleProfessorMenu(verified_professor);
                        }
                        else if (userType.equals("Admin"))
                        {
                            Admin verified_admin = (Admin) user;
                            handleAdminMenu(verified_admin);
                        }
                        else if (userType.equals("Ta"))
                        {
                            Ta verified_ta = (Ta) user;
                            handleTaMenu(verified_ta);
                        }
                        return;
                    }
                    else
                        System.out.println("\nIncorrect Password, Try Again");
                }
                else
                    System.out.println("\nIncorrect Email, Try again");

                attempts--;
                System.out.println("\nAttempts remaining: " + attempts);
            }

            throw new InvalidLoginException("Too many failed attempts to login.");
        }
        catch (InvalidLoginException e)
        {
            System.out.println(e.getMessage());
        }
        catch (Exception e)
        {
            System.out.println("Error 101 : user authentication " + e.getMessage());
        }
    }

    private static void handleTaMenu(Ta verified_ta)
    {
        Scanner scanner = new Scanner(System.in);
        String query = "";

        while (!query.equals("11"))
        {
            verified_ta.showMenu();
            query = scanner.nextLine();

            switch (query)
            {
                case "1":
                    verified_ta.courseMenu();
                    break;
                case "2":
                    verified_ta.RegisterForCourses();
                    break;
                case "3":
                    verified_ta.ListAllCourses();
                    break;
                case "4":
                    verified_ta.ViewSchedule();
                    break;
                case "5":
                    verified_ta.TrackAcademicProgress();
                    break;
                case "6":
                    verified_ta.DropCourses();
                    break;
                case "7":
                    verified_ta.ViewComplaints();
                    break;
                case "8":
                    verified_ta.SubmitComplaint();
                    break;
                case "9":
                    verified_ta.showCourses();
                    break;
                case "10":
                    verified_ta.manageGrades();
                    break;
                case "11":
                    System.out.println("\nSuccessfully Logged Out ! ");
                    return;
                default:
                    System.out.println("\nPlease choose a valid option");
                    break;
            }
        }
    }

    public static void handleAdminMenu(Admin verified_admin)
    {
        Scanner scanner = new Scanner(System.in);
        String query = "";

        while (!query.equals("5"))
        {
            verified_admin.showMenu();
            query = scanner.nextLine();

            switch (query) {
                case "1":
                    verified_admin.ManageCourseCatalog();
                    break;
                case "2":
                    verified_admin.ManageStudentRecords();
                    break;
                case "3":
                    verified_admin.AssignProfessor();
                    break;
                case "4":
                    verified_admin.HandleComplaints();
                    break;
                case "5":
                    System.out.println("\nSuccessfully Logged Out ! ");
                    return;
                default:
                    System.out.println("\nPlease choose a valid input");
                    break;
            }
        }
    }

    public static void handleProfessorMenu(Professor verified_prof)
    {
        Scanner scanner = new Scanner(System.in);
        String query = "";

        while (!query.equals("3"))
        {
            verified_prof.showMenu();
            query = scanner.nextLine();

            switch (query) {
                case "1":
                    verified_prof.ManageCourses();
                    break;
                case "2":
                    verified_prof.ViewEnrolledStudents();
                    break;
                case "3":
                    System.out.println("\nSuccessfully Logged Out ! ");
                    return;
                default:
                    System.out.println("\nPlease choose a valid input");
                    break;
            }
        }
    }

    public static void handleStudentMenu(Student verified_student)
    {
        Scanner scanner = new Scanner(System.in);
        String query = "";

        while (!query.equals("10"))
        {
            verified_student.showMenu();
            query = scanner.nextLine();

            switch (query)
            {
                case "1":
                    verified_student.courseMenu();
                    break;
                case "2":
                    verified_student.RegisterForCourses();
                    break;
                case "3":
                    verified_student.ListAllCourses();
                    break;
                case "4":
                    verified_student.ViewSchedule();
                    break;
                case "5":
                    verified_student.TrackAcademicProgress();
                    break;
                case "6":
                    verified_student.DropCourses();
                    break;
                case "7":
                    verified_student.SubmitComplaint();
                    break;
                case "8":
                    verified_student.ViewComplaints();
                    break;
                case "9":
                    verified_student.giveFeedback();
                    break;
                case "10":
                    System.out.println("\nSuccessfully Logged Out ! ");
                    return;
                default:
                    System.out.println("\nPlease choose a valid option");
                    break;
            }
        }
    }

    public static void mainmenu1()
    {
        System.out.println();
        System.out.println("-------------------------------------------------------");
        System.out.println("-                      Main Menu                      -");
        System.out.println("-------------------------------------------------------");
        System.out.println("Welcome to ERP");
        System.out.println("1. Login");
        System.out.println("2. Signup");
        System.out.println("3. Exit");
        System.out.println("-------------------------------------------------------");
    }

    public static void mainmenu2()
    {
        System.out.println();
        System.out.println("-------------------------------------------------------");
        System.out.println("-                     Login Menu                      -");
        System.out.println("-------------------------------------------------------");
        System.out.println("1. Login as Student");
        System.out.println("2. Login as Professor");
        System.out.println("3. Login as Administrator");
        System.out.println("4. Login as Teaching Assistant");
        System.out.println("5. Go Back");
        System.out.println("-------------------------------------------------------");
    }

    public static void mainmenu3()
    {
        System.out.println();
        System.out.println("-------------------------------------------------------");
        System.out.println("-                    SignUp Menu                      -");
        System.out.println("-------------------------------------------------------");
        System.out.println("1. Signup as Student");
        System.out.println("2. Signup as Professor");
        System.out.println("3. Signup as Administrator");
        System.out.println("4. Signup as Teaching Assistant");
        System.out.println("5. Go Back");
        System.out.println("-------------------------------------------------------");
    }
}