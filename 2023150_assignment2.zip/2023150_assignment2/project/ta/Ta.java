package project.ta;
import project.professor.Professor;
import project.student.Student;
import project.models.*;
import java.util.*;

public class Ta extends Student
{
    private static final List<Ta> allTas = new ArrayList<>();
    private static final List<Course> myCourses = new ArrayList<>();
    private static HashMap<String, Integer> studentGrades;

    static
    {
        // Create TAs and assigning them to courses
        Ta ta1 = new Ta("ta1@iiitd.ac.in", "1234", "TA");
        ta1.addCourse(Coursecatalog.getCoursesForSemester(1).get(0));

        Ta ta2 = new Ta("ta2@iiitd.ac.in", "1234", "TA");
        ta2.addCourse(Coursecatalog.getCoursesForSemester(1).get(2));

        Ta ta3 = new Ta("ta3@iiitd.ac.in", "1234", "TA");
        ta2.addCourse(Coursecatalog.getCoursesForSemester(1).get(1));
    }

    private void addCourse(Course course)
    {
        myCourses.add(course);
    }

    public Ta(String email, String password, String type)
    {
        super(email, password, type);
        allTas.add(this);
        studentGrades = new HashMap<>();
    }

    public void showCourses()
    {
        try
        {
            if (myCourses.isEmpty())
                System.out.println("\nCurrently you are not a TA for any course");
            else
            {
                System.out.println("\n-------------------------------------------------------");
                System.out.println("Currently you are TA of following courses :");
                for (Course course : myCourses)
                {
                    System.out.println("Course Code: " + course.getCourseCode() + ", Title: " + course.getTitle());
                }
                System.out.println("-------------------------------------------------------");
            }
        }
        catch (Exception e)
        {
            System.out.println("\nError showing courses in TA : " + e.getMessage());
        }
    }

    public void viewStudentGrades()
    {
        try
        {
            if (myCourses.isEmpty())
                System.out.println("\nCurrently you are not a TA for any course");
            else
            {
                System.out.println("\nThe grades of students are : ");
                for (String key : studentGrades.keySet())
                {
                    System.out.println(key + ": " + studentGrades.get(key));
                }
            }
        }
        catch (Exception e)
        {
            System.out.println("\nError viewing grades in TA : " + e.getMessage());
        }
    }

    public void manageGrades()
    {
        try
        {
            Scanner scanner = new Scanner(System.in);
            String query = "";

            while (query != "back")
            {
                System.out.println("\nEnter \"view\" to view student grades, \"update\" to update student grades, and \"back\" to go back: ");
                query = scanner.nextLine();

                if (query.equals("back"))
                    break;
                else if (query.equals("view"))
                    viewStudentGrades();
                else if (query.equals("update"))
                {
                    if (myCourses.isEmpty())
                        System.out.println("\nCurrently you are not a TA for any course");
                    else
                    {
                        System.out.println("\nEnter the course code : ");
                        String courseCode = scanner.nextLine().trim();

                        boolean courseFound = false;
                        for (Course course : myCourses)
                        {
                            if (course.getCourseCode().equals(courseCode))
                            {
                                courseFound = true;
                                break;
                            }
                        }

                        if (!courseFound)
                        {
                            System.out.println("\nYou are not a TA for the course : " + courseCode);
                            continue;
                        }

                        System.out.println("\nEnter the student's email address : ");
                        String studentEmail = scanner.nextLine();

                        System.out.println("\nEnter the new grade for " + studentEmail + " : ");
                        String gradeString = scanner.nextLine();

                        try
                        {
                            int grade = Integer.parseInt(gradeString);
                            studentGrades.put(studentEmail, grade);
                            System.out.println("\nGrade for " + studentEmail + " in " + courseCode + " updated to " + grade);
                        }
                        catch (NumberFormatException e)
                        {
                            System.out.println("\nError : Invalid grade entered. Please enter a valid number");
                        }
                    }
                }
                else
                    System.out.println("\nInvalid query");
            }
        }
        catch (Exception e)
        {
            System.out.println("\nError updating grades in TA : " + e.getMessage());
        }
    }

    public void showMenu()
    {
        System.out.println();
        System.out.println("-------------------------------------------------------");
        System.out.println("-                      TA Menu                        -");
        System.out.println("-------------------------------------------------------");
        System.out.println("1. View Available Courses");
        System.out.println("2. Register for Courses");
        System.out.println("3. Track All Course");
        System.out.println("4. View Schedule");
        System.out.println("5. Track Academic Progress");
        System.out.println("6. Drop Courses");
        System.out.println("7. Submit Complaints");
        System.out.println("8. View Complaints");
        System.out.println("9. Show Courses (as a TA)");
        System.out.println("10. Manage Grades");
        System.out.println("11. Logout");
        System.out.println("-------------------------------------------------------");
    }
}