package project.student;
import java.util.*;
import project.models.*;
import project.models.Feedback;
import static project.models.Coursecatalog.*;
import static project.professor.Professor.updatefeedbackList;
import java.time.format.DateTimeFormatter;
import java.time.LocalDateTime;

public class Student extends User
{
    private static List<Student> allStudents = new ArrayList<>();
    private String academicStanding;
    private String contactDetails;
    private int current_semester;
    public int credits;
    public final LinkedList<Course> enrolled_courses;
    private final HashMap<String, String> grades;
    private LinkedList<Complaint> complaints;
    private ArrayList<Feedback<?>> feedbackList;

    public Student(String email, String password, String type)
    {
        super(email, password, type);
        this.credits = 0;
        this.current_semester = 1;
        this.enrolled_courses = new LinkedList<>();
        this.complaints = new LinkedList<>();
        this.grades = new HashMap<>();
        this.contactDetails = email;
        allStudents.add(this);
        this.feedbackList = new ArrayList<>();
    }

    public void courseMenu()
    {
        Scanner scanner = new Scanner(System.in);
        System.out.println("\nEnter the semester you want to view courses for : ");
        int semester = scanner.nextInt();

        List<Course> availableCourses = getCoursesForSemester(semester);

        if (availableCourses == null || availableCourses.isEmpty())
            System.out.println("\nNo courses available for semester " + semester);
        else
        {
            System.out.println("\nCourses available for semester " + semester + ":");
            for (Course course : availableCourses)
            {
                System.out.println("-------------------------------------------------------");
                System.out.println("Course Code: " + course.getCourseCode());
                System.out.println("Course Title: " + course.getTitle());
                System.out.println("Professor: " + course.getProfessor());
                System.out.println("Credits: " + course.getCredits());
                System.out.println("Prerequisites: " + course.getPrerequisites());
                System.out.println("Timings: " + course.getTimings());
                System.out.println("-------------------------------------------------------");
            }
        }
    }

    public void RegisterForCourses()
    {
        Scanner scanner = new Scanner(System.in);
        System.out.println("\nEnter the semester you want to register for : ");
        int semester = scanner.nextInt();

        List<Course> availableCourses = Coursecatalog.getCoursesForSemester(semester);

        if (availableCourses == null || availableCourses.isEmpty())
        {
            System.out.println("No courses available for semester " + semester);
            return;
        }

        System.out.println("Available courses for semester " + semester + ":");
        int count = 1;
        for (Course course : availableCourses)
        {
            System.out.println(count + ". " + course.getCourseCode() + " - " + course.getTitle());
            count++;
        }

        System.out.println("\nEnter the number of the course you want to register for : ");
        int courseIndex = scanner.nextInt();

        if (courseIndex > 0 && courseIndex <= availableCourses.size())
        {
            Course selectedCourse = availableCourses.get(courseIndex - 1);

            // Check if the student is already enrolled in this course
            if (isEnrolledInCourse(selectedCourse.getCourseCode()))
            {
                System.out.println("\nYou are already enrolled in this course.");
                return;
            }

            // Check enrollment limit is reached or not
            if (selectedCourse.getEnrollmentLimit() <= selectedCourse.getEnrolledStudents().size())
            {
                try
                {
                    throw new CourseFullException("You cannot register for this course as the course " + selectedCourse.getTitle() + " is already full.");
                }
                catch (CourseFullException e)
                {
                    System.out.println(e.getMessage());
                    return;
                }
            }

            // haven't registered for 20 credits yet
            if (this.credits + selectedCourse.getCredits() > 20)
            {
                System.out.println("\nYou cannot register for more than 20 credits. Your quota is full.");
                return;
            }

            // pre req check
            List<String> prerequisites = selectedCourse.getPrerequisites();
            boolean meetsPrerequisites = true;

            if (!prerequisites.isEmpty())
            {
                for (String prereq : prerequisites)
                {
                    if (!hasCompletedCourse(prereq))
                    {
                        meetsPrerequisites = false;
                        System.out.println("You do not meet the prerequisite : " + prereq);
                    }
                }
            }

            if (meetsPrerequisites)
            {
                enrolled_courses.add(selectedCourse);
                this.credits += selectedCourse.getCredits();
                selectedCourse.enrollStudent(this);
                System.out.println("You have successfully registered for " + selectedCourse.getTitle());
            }
            else
                System.out.println("\nYou cannot register for this course due to unmet prerequisites");
        }
        else
            System.out.println("\nInvalid selection");
    }

    public void ListAllCourses()
    {
        if(enrolled_courses.isEmpty())
            System.out.println("\nYou haven't registered for any courses yet");
        else
        {
            System.out.println("\nYour enrolled courses are : ");
            for (Course course : enrolled_courses)
                System.out.println(course);
        }
    }

    public void ViewSchedule()
    {
        if (enrolled_courses.isEmpty())
        {
            System.out.println("\nYou are not enrolled in any courses");
            return;
        }

        System.out.println("\nYour weekly course schedule :");
        for (Course course : enrolled_courses)
        {
            System.out.println("-------------------------------------------------------");
            System.out.println("Course Title: " + course.getTitle());
            System.out.println("Course Code: " + course.getCourseCode());
            System.out.println("Professor: " + course.getProfessor());
            System.out.println("Timings: " + course.getTimings());
            System.out.println("-------------------------------------------------------");
        }
    }

    public void TrackAcademicProgress()
    {
        if (enrolled_courses.isEmpty())
            System.out.println("\nYou are not enrolled in any courses");
        else if (grades.isEmpty())
            System.out.println("\nGrades aren't available yet");
        else
        {
            System.out.println("\nYour academic progress :");

            double totalGradePoints = 0.0;
            double totalCredits = 0.0;
            List<Double> currentSemesterGradePoints = new ArrayList<>();
            int currentSemesterCredits = 0;

            for (Course course : enrolled_courses)
            {
                String gradeStr = grades.getOrDefault(course.getCourseCode(), "Not graded yet");
                System.out.println(course.getCourseCode() + " - " + course.getTitle() + ": " + gradeStr);

                if (!gradeStr.equals("\nNot graded yet"))
                {
                    double grade = Double.parseDouble(gradeStr);
                    if (grade < 0 || grade > 10)
                    {
                        System.out.println("Invalid grade for " + course.getTitle() + ". Must be between 0 and 10.");
                        continue;
                    }

                    totalGradePoints += grade * course.getCredits();
                    totalCredits += course.getCredits();
                    currentSemesterGradePoints.add(grade);
                    currentSemesterCredits += course.getCredits();
                }
            }

            if (totalCredits > 0)
            {
                double cgpa = totalGradePoints / totalCredits;
                System.out.println("Your current CGPA is : " + String.format("%.2f", cgpa));
            }

            if (currentSemesterCredits > 0)
            {
                double sgpa = currentSemesterGradePoints.stream().mapToDouble(gp -> gp).sum() / currentSemesterCredits;
                System.out.println("Your SGPA for the current semester is : " + String.format("%.2f", sgpa));
            }
        }
    }

    public void DropCourses()
    {
        if(enrolled_courses.isEmpty())
            System.out.println("\nYou are not enrolled for any courses at this moment ! ");
        else
        {
            System.out.println("\nYour enrolled courses are : ");
            int count = 1;
            for (Course course : enrolled_courses)
            {
                System.out.println(count + ". " + course.getTitle());
                count++;
            }

            Scanner scanner = new Scanner(System.in);
            System.out.println("\nEnter the number of the course you want to drop : ");
            int courseIndex = scanner.nextInt();

            DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss");
            LocalDateTime now = LocalDateTime.now();
            LocalDateTime deadline = Course.getDeadline();

            if (now.isAfter(deadline))
            {
                try
                {
                    throw new DropDeadlineException("You cannot drop the course after the deadline of " + deadline.format(dtf) + ".");
                }
                catch (DropDeadlineException e)
                {
                    System.out.println(e.getMessage());
                }
            }
            else if (courseIndex > 0 && courseIndex <= enrolled_courses.size())
            {
                Course courseToDrop = enrolled_courses.get(courseIndex - 1);

                courseToDrop.getEnrolledStudents().remove(this);

                this.credits -= courseToDrop.getCredits();

                enrolled_courses.remove(courseToDrop);

                System.out.println("You have successfully dropped the course : " + courseToDrop.getTitle());
            }
            else
                System.out.println("\nInvalid course selection");
        }
    }

    public void SubmitComplaint()
    {
        Scanner scanner = new Scanner(System.in);
        System.out.println("\nEnter your complaint : ");
        String complaintText = scanner.nextLine();

        if (complaintText.trim().isEmpty())
            System.out.println("\nInvalid complaint !");
        else
        {
            Complaint newComplaint = new Complaint(complaintText);
            Complaint.addComplaint(newComplaint);
            complaints.add(newComplaint);
            System.out.println("\nYour complaint has been successfully submitted.");
        }
    }

    public void ViewComplaints()
    {
        if(complaints.isEmpty())
            System.out.println("\nComplaint list is empty");
        else
        {
            System.out.println("\nYour complaints are:");
            for (Complaint complaint : complaints)
            {
                System.out.println("-------------------------------------------------------");
                System.out.println("Complaint: " + complaint.getText());
                System.out.println("Status: " + complaint.getStatus());
                System.out.println("-------------------------------------------------------");
            }
        }
    }

    public <T> void giveFeedback()
    {
        Scanner scanner = new Scanner(System.in);
        System.out.print("\nEnter course code : ");
        String courseCode = scanner.nextLine();

        if(!hasCompletedCourse(courseCode))
            System.out.println("\nYou haven't completed the course yet");
        else
        {
            System.out.println("\nEnter your feedback : ");

            if (scanner.hasNextInt())
            {
                int rating = scanner.nextInt();
                Feedback<Integer> feedback = new Feedback<>(courseCode, rating);
                feedbackList.add(feedback);
                updatefeedbackList(courseCode, "" + rating);
            }
            else
            {
                String text = scanner.nextLine();
                Feedback<String> feedback = new Feedback<>(courseCode, text);
                feedbackList.add(feedback);
                // typecast to string is redundant but keep it!!!!!!!!!!!
                updatefeedbackList(courseCode, (String) text);
            }

            System.out.println("\nYour feedback was successfully submitted !");
        }
    }

    // helper functions
    public static List<Student> getAllStudents()
    {
        return new ArrayList<>(allStudents);
    }

    public static Student getStudentByEmail(String email)
    {
        for (Student student : allStudents)
        {
            if (student.getEmail().equalsIgnoreCase(email))
                return student;
        }
        return null;
    }

    public String getAcademicStanding()
    {
        return academicStanding;
    }

    public String getContactDetails()
    {
        return contactDetails;
    }

    public void updateGrade(String courseCode, String grade)
    {
        if (enrolled_courses.stream().anyMatch(course -> course.getCourseCode().equals(courseCode)))
        {
            grades.put(courseCode, grade);
            System.out.println("Grade for " + courseCode + " updated to " + grade);
        }
        else
            System.out.println("\nNot enrolled in the course " + courseCode);
    }

    public void viewGrades()
    {
        if (grades.isEmpty())
            System.out.println("\nNo grades available.");
        else
        {
            System.out.println("\nGrades are :");
            for (Map.Entry<String, String> entry : grades.entrySet())
            {
                System.out.println("Course Code: " + entry.getKey() + ", Grade: " + entry.getValue());
            }
        }
    }

    // Helper method to check if a student is already enrolled in a course
    public boolean isEnrolledInCourse(String courseCode)
    {
        for (Course course : enrolled_courses)
        {
            if (course.getCourseCode().equals(courseCode))
                return true;
        }
        return false;
    }

    // Helper to check if pre req is met
    private boolean hasCompletedCourse(String courseCode)
    {
        for (Course course : enrolled_courses)
        {
            if (course.getCourseCode().equals(courseCode))
            {
                String grade = grades.get(courseCode);
                return grade != null ;
                //return grade != null && !grade.equals("\nNot graded yet");
            }
        }
        return false;
    }

    public void setEmail(String newEmail)
    {
        if (newEmail == null || newEmail.isEmpty())
        {
            System.out.println("\nEmail cannot be null or empty.");
            return;
        }

        // Simple email validation
        if (newEmail.contains("@") && newEmail.indexOf("@") > 0 && newEmail.lastIndexOf(".") > newEmail.indexOf("@") + 1)
        {
            this.contactDetails = newEmail;
            System.out.println("Email updated to: " + newEmail);
        }
        else
            System.out.println("\nInvalid email format.");
    }
    // end of helper functions

    // will come of use someday
    public ArrayList<Feedback<?>> getFeedbackList()
    {
        return feedbackList;
    }

    public void setAcademicStanding(String newStanding) {
        this.academicStanding = newStanding;
    }

    public void setContactDetails(String newContactDetails) {
        this.contactDetails = newContactDetails;
    }

    public int getCurrentSemester()
    {
        return this.current_semester;
    }

    // misc
    public void showMenu()
    {
        System.out.println();
        System.out.println("-------------------------------------------------------");
        System.out.println("-                   Student Menu                      -");
        System.out.println("-------------------------------------------------------");
        System.out.println("1. View Available Courses");
        System.out.println("2. Register for Courses");
        System.out.println("3. Track All Course");
        System.out.println("4. View Schedule");
        System.out.println("5. Track Academic Progress");
        System.out.println("6. Drop Courses");
        System.out.println("7. Submit Complaints");
        System.out.println("8. View Complaints");
        System.out.println("9. Give Feedback");
        System.out.println("10. Logout");
        System.out.println("-------------------------------------------------------");
    }
}