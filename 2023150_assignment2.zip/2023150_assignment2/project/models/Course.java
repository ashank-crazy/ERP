package project.models;

import project.professor.Professor;
import project.student.Student;

import java.time.LocalDateTime;
import java.util.*;

public class Course
{
    private final String courseCode;
    private final String title;
    private Professor professor; 
    private int credits;
    private String timings; 
    private List<String> prerequisites;
    private final List<Student> enrolledStudents;
    private int enrollmentLimit; 
    private String syllabus;
    private static LocalDateTime deadline;

    public Course(String courseCode, String title, Professor professor, int credits, List<String> prerequisites, String timings)
    {
        this.courseCode = courseCode;
        this.title = title;
        this.professor = professor;
        this.credits = credits;
        this.prerequisites = prerequisites;
        this.timings = timings;
        this.enrolledStudents = new ArrayList<>();
        this.enrollmentLimit = 5;
        this.deadline = null;
    }

    public List<Student> getEnrolledStudents()
    {
        return enrolledStudents;
    }

    public static LocalDateTime getDeadline()
    {
        return deadline;
    }

    public void setDeadline(LocalDateTime deadline)
    {
        this.deadline = deadline;
    }

    public void enrollStudent(Student student)
    {
        if (enrolledStudents.contains(student))
            System.out.println("Student already enrolled in the course : " + title);
        else if (enrolledStudents.size() < enrollmentLimit)
            enrolledStudents.add(student);
        else
            System.out.println("Enrollment limit reached for course : " + title);
    }

    public String getCourseCode()
    {
        return courseCode;
    }

    public String getTitle()
    {
        return title;
    }

    public Professor getProfessor()
    {
        return professor;
    }

    public void setProfessor(Professor professor)
    {
        this.professor = professor;
    }

    public int getCredits()
    {
        return credits;
    }

    public List<String> getPrerequisites()
    {
        return prerequisites != null ? prerequisites : Collections.emptyList();
    }

    public String getTimings()
    {
        return timings;
    }

    public int getEnrollmentLimit()
    {
        return enrollmentLimit;
    }

    @Override
    public String toString()
    {
        return courseCode + ": " + title + " by " + (professor != null ? professor.getName() : "No professor has been assigned");
    }

    public void setPrerequisites(List<String> prerequisites)
    {
        this.prerequisites = prerequisites;
    }

    public void setEnrollmentLimit(int enrollmentLimit)
    {
        if (enrollmentLimit <= 0)
        {
            throw new IllegalArgumentException("\nEnrollment limit must be greater than zero");
        }
        else
            this.enrollmentLimit = enrollmentLimit;
    }

    // will find a use some day
    public void prePopulate(String professorEmail, List<Professor> professors)
    {
        for (Professor professor : professors)
        {
            if (professor.getEmail().equals(professorEmail))
            {
                this.professor = professor;
                System.out.println("Assigned professor " + professor.getName() + " to course " + this.title);
                return;
            }
        }
    }

    public void setCredits(int credits)
    {
        if (credits <= 0)
        {
            throw new IllegalArgumentException("\nCredits must be greater than zero");
        }
        else
            this.credits = credits;
    }

    public void setTimings(String timings)
    {
        this.timings = timings;
    }

    public void setSyllabus(String syllabus)
    {
        this.syllabus = syllabus;
    }
}