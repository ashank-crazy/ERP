package project.models;

public interface Systeminterface
{
    void showMenu();
}