package project.models;

import java.util.ArrayList;
import java.util.List;

public class Complaint
{
    // for all the complaints by all the users
    private static final List<Complaint> complaints = new ArrayList<>();

    private final String complaintText;
    private String status;

    public Complaint(String complaintText)
    {
        this.complaintText = complaintText;
        this.status = "Pending";
    }

    // to add a complaint
    public static void addComplaint(Complaint complaint)
    {
        complaints.add(complaint);
    }

    // to get all complaints
    public static List<Complaint> getComplaints()
    {
        return complaints;
    }

    // to return the complaint
    public String getComplaintText()
    {
        return complaintText;
    }

    // to return the status of complaint
    public String getStatus()
    {
        return status;
    }

    // to update the status of complaint
    public void setStatus(String status)
    {
        this.status = status;
    }

    @Override
    public String toString()
    {
        return "Complaint: " + complaintText + " | Status: " + status;
    }

    public String getText()
    {
        return complaintText;
    }
}