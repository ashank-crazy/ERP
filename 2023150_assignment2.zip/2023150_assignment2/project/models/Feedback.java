package project.models;
import java.util.*;

public class Feedback<T>
{
    private final String courseCode;
    private final List<T> feedbacks;

    public Feedback(String courseCode, T feedback)
    {
        this.courseCode = courseCode;
        this.feedbacks = new ArrayList<>();
    }

    // will come of use some day
    public void addFeedback(T feedback)
    {
        feedbacks.add(feedback);
    }

    public String getCourseCode()
    {
        return courseCode;
    }

    public List<T> getFeedbacks()
    {
        return feedbacks;
    }

    // misc
    @Override
    public String toString()
    {
        return "Feedback [courseCode : " + courseCode + ", feedbacks : " + feedbacks + "]";
    }
}