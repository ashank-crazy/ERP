package project.models;

public class DropDeadlineException extends Exception
{
    public DropDeadlineException(String message) {
        super(message);
    }
}
