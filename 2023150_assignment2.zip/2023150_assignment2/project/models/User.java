package project.models;

public abstract class User implements Systeminterface
{
    private final String email;
    private final String password;
    private final String type;

    public User(String email, String password, String type)
    {
        this.email = email;
        this.password = password;
        this.type = type;
    }

    public String getEmail()
    {
        return email;
    }

    public boolean authenticate(String password, String type)
    {
        return this.password.equals(password) && this.type.equals(type);
    }

    public String getPassword()
    {
        return password;
    }
}