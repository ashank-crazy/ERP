package project.professor;

import project.models.*;
import project.student.Student;
import java.util.*;

public class Professor extends User
{
    private static LinkedList<Course> courses;
    private static HashMap<String,List<String> > feedbackList;

    public Professor(String email, String password, String type)
    {
        super(email, password, type);
        courses = new LinkedList<>();
        feedbackList = new HashMap<>();
    }

    public void ManageCourses()
    {
        Scanner scanner = new Scanner(System.in);

        while (true)
        {
            if (courses.isEmpty())
            {
                System.out.println("\nYou aren't teaching any courses at the moment.");
                return;
            }

            // Display all courses
            System.out.println("\nManage Courses : ");
            for (int i = 0; i < courses.size(); i++)
            {
                Course course = courses.get(i);
                System.out.println((i + 1) + ". " + course.getTitle() + " (" + course.getCourseCode() + ")");
            }

            System.out.println("\nEnter the course number to manage (0 to exit): ");
            int courseNumber = scanner.nextInt();
            scanner.nextLine();

            if (courseNumber == 0)
                return;
            else if (courseNumber > 0 && courseNumber <= courses.size())
            {
                Course selectedCourse = courses.get(courseNumber - 1);
                manageCourseDetails(selectedCourse, scanner);
            }
            else
                System.out.println("\nInvalid course number.");
        }
    }

    public void ViewEnrolledStudents()
    {
        if (courses.isEmpty())
            System.out.println("\nYou aren't teaching any courses at the moment.");
        else
        {
            for (Course course : courses)
            {
                List<Student> enrolledStudents = course.getEnrolledStudents();

                System.out.println("Course: " + course.getTitle() + " (" + course.getCourseCode() + ")");
                if (enrolledStudents.isEmpty())
                    System.out.println("\nNo students are enrolled in this course.");
                else
                {
                    System.out.println("\nEnrolled Students : ");
                    for (Student student : enrolledStudents)
                    {
                        System.out.println("\n---------------------------------------");
                        System.out.println("Email: " + student.getEmail());
                        System.out.println("Academic Standing: " + student.getAcademicStanding());
                        System.out.println("Contact Details: " + student.getContactDetails());
                        System.out.println("---------------------------------------");
                    }
                }
                System.out.println();
            }
        }
    }

    // helper functions
    private void manageCourseDetails(Course course, Scanner scanner)
    {
        while (true)
        {
            System.out.println();
            System.out.println("Managing Course: " + course.getTitle());
            System.out.println("1. Update Syllabus");
            System.out.println("2. Update Class Timings");
            System.out.println("3. Update Credits");
            System.out.println("4. Update Prerequisites");
            System.out.println("5. Update Enrollment Limit");
            System.out.println("6. View Course Feedback");
            System.out.println("7. Back to Course List");
            System.out.print("\nChoose an option: ");
            System.out.println();

            int option = scanner.nextInt();
            scanner.nextLine();

            switch (option)
            {
                case 1:
                    System.out.print("\nEnter new syllabus: ");

                    String syllabus = scanner.nextLine();
                    course.setSyllabus(syllabus);

                    System.out.println("\nSyllabus updated successfully.");
                    break;
                case 2:
                    System.out.print("\nEnter new class timings: ");

                    String timings = scanner.nextLine();
                    course.setTimings(timings);

                    System.out.println("\nClass timings updated successfully.");
                    break;
                case 3:
                    System.out.print("\nEnter new credits: ");

                    int credits = scanner.nextInt();
                    scanner.nextLine();

                    course.setCredits(credits);
                    System.out.println("\nCredits updated successfully.");
                    break;
                case 4:
                    System.out.print("\nEnter new prerequisites (comma-separated): ");
                    String prereqs = scanner.nextLine();

                    List<String> prerequisites = new ArrayList<>();
                    String[] parts = prereqs.split(",");

                    for (String part : parts)
                        prerequisites.add(part.trim());

                    course.setPrerequisites(prerequisites);

                    System.out.println("\nPrerequisites updated successfully.");
                    break;
                case 5:
                    System.out.print("\nEnter new enrollment limit: ");

                    int enrollmentLimit = scanner.nextInt();
                    scanner.nextLine();

                    course.setEnrollmentLimit(enrollmentLimit);
                    System.out.println("\nEnrollment limit updated successfully.");
                    break;
                case 6:
                    viewCourseFeedback(course);
                    break;
                case 7:
                    return;
                default:
                    System.out.println("\nInvalid option. Please try again.");
            }
        }
    }

    public static void updatefeedbackList(String courseCode, String feedback)
    {
        List<String> feedbacks = feedbackList.get(courseCode);

        // if feedbacks is empty
        if (feedbacks == null)
            feedbacks = new ArrayList<>();

        feedbacks.add(feedback);
        feedbackList.put(courseCode, feedbacks);
    }

    private void viewCourseFeedback(Course courseCode)
    {
        List<String> feedbacks = null;
        if (feedbackList.containsKey(courseCode.getCourseCode()))
        {
            feedbacks = feedbackList.get(courseCode.getCourseCode());
            System.out.println("Feedback for course " + courseCode.getTitle() + ":");
            int cnt = 0;
            for (String feedback : feedbacks)
            {
                cnt++;
                System.out.println(cnt + " : " + feedback);
            }
        }
        else
        {
            System.out.println("No feedback available for course " + courseCode.getTitle());
        }
    }


    public static void addCourse(Course course)
    {
        courses.add(course);
    }

    // end of helper functions

    // misc
    public static List<Professor> getAllProfessors()
    {
        return Arrays.asList
        (
            new Professor("bnj@iiitd.ac.in", "1234", "Professor"),
            new Professor("pvb@iiitd.ac.in", "1234", "Professor"),
            new Professor("pcm@iiitd.ac.in", "1234", "Professor"),
            new Professor("rrs@iiitd.ac.in", "1234", "Professor"),
            new Professor("smc@iiitd.ac.in", "1234", "Professor"),
            new Professor("ojs@iiitd.ac.in", "1234", "Professor"),
            new Professor("tmt@iiitd.ac.in", "1234", "Professor"),
            new Professor("kkk@iiitd.ac.in", "1234", "Professor"),
            new Professor("sdb@iiitd.ac.in", "1234", "Professor"),
            new Professor("sgc@iiitd.ac.in", "1234", "Professor"),
            new Professor("Default_professor@iiitd.ac.in","1234","Professor"),
            new Professor("prof1@iiitd.ac.in","1234","Professor"),
            new Professor("prof2@iiitd.ac.in","1234","Professor"),
            new Professor("prof3@iiitd.ac.in","1234","Professor")
        );
    }

    public String getName()
    {
        return getEmail();
    }

    @Override
    public String toString()
    {
        return getEmail();
    }

    public void showMenu()
    {
        System.out.println("\n-------------------------------------------------------");
        System.out.println("-                  Professor Menu                     -");
        System.out.println("-------------------------------------------------------");
        System.out.println("1. Manage Courses");
        System.out.println("2. View Enrolled Students");
        System.out.println("3. Logout");
        System.out.println("-------------------------------------------------------");
    }
}