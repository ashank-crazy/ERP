package project.admin;

import java.util.*;
import project.models.*;
import project.professor.Professor;
import project.student.Student;
import java.time.format.DateTimeFormatter;
import java.time.LocalDateTime;

public class Admin extends User
{
    public Admin(String email, String password, String type)
    {
        super(email, password, type);
    }

    public void ManageCourseCatalog()
    {
        Scanner scanner = new Scanner(System.in);

        while (true)
        {
            System.out.println("-------------------------------------------------------");
            System.out.println("Manage Course Catalog :");
            System.out.println("1. View All Courses");
            System.out.println("2. Add Course");
            System.out.println("3. Delete Course");
            System.out.println("4. Assign Deadline to Course");
            System.out.println("5. Return to Menu");
            System.out.println("-------------------------------------------------------\n");
            System.out.print("Choose an option : \n");
            int option = scanner.nextInt();
            scanner.nextLine();

            switch (option)
            {
                case 1:
                    viewAllCourses();
                    break;
                case 2:
                    addCourse(scanner);
                    break;
                case 3:
                    deleteCourse(scanner);
                    break;
                case 4:
                    handleDeadline(scanner);
                    break;
                case 5:
                    return;
                default:
                    System.out.println("\nInvalid option. Please try again.");
            }
        }
    }

    public void ManageStudentRecords()
    {
        Scanner scanner = new Scanner(System.in);

        while (true)
        {
            System.out.println("\nManage Student Records :");
            System.out.println("1. View All Students");
            System.out.println("2. Update Student Information");
            System.out.println("3. Return to Menu\n");
            System.out.println("Choose an option : ");
            int option = scanner.nextInt();
            scanner.nextLine();

            switch (option)
            {
                case 1:
                    viewAllStudents();
                    break;
                case 2:
                    updateStudentInformation(scanner);
                    break;
                case 3:
                    return;
                default:
                    System.out.println("\nInvalid option. Please try again.");
            }
        }
    }

    public void AssignProfessor()
    {
        Scanner scanner = new Scanner(System.in);

        // Get all courses from the catalog
        List<Course> courses = Coursecatalog.getAllCourses();

        // If no courses are available
        if (courses.isEmpty())
        {
            System.out.println("\nNo courses available to assign professors.");
            return;
        }

        // Display all courses
        System.out.println("\nCourses : ");
        int index = 1;
        for (Course course : courses)
        {
            System.out.println(index + ". " + course.getCourseCode() + " - " + course.getTitle() +
                    " | Current Professor : " + (course.getProfessor() != null ? course.getProfessor().getName() : "None"));
            index++;
        }

        // Select a course to assign a professor
        System.out.println("\nEnter the course number you want to assign a professor to (0 to exit) : ");
        int courseNumber = scanner.nextInt();

        if (courseNumber == 0)
            return;
        else if (courseNumber > 0 && courseNumber <= courses.size())
        {
            Course selectedCourse = courses.get(courseNumber - 1);

            // Get all professors again
            List<Professor> professors = Professor.getAllProfessors();

            // If no professors available
            if (professors.isEmpty())
            {
                System.out.println("\nNo professors available.");
                return;
            }

            // Display all professors again
            System.out.println("\nAvailable Professors:");
            index = 1;
            for (Professor professor : professors)
            {
                System.out.println(index + ". " + professor.getName() + " (" + professor.getEmail() + ")");
                index++;
            }

            System.out.println("\nEnter the professor number to assign (0 to exit): ");
            int professorNumber = scanner.nextInt();

            if (professorNumber == 0)
                return;

            if (professorNumber > 0 && professorNumber <= professors.size())
            {
                Professor selectedProfessor = professors.get(professorNumber - 1);
                selectedCourse.setProfessor(selectedProfessor);
                Professor.addCourse(selectedCourse);

                System.out.println("Professor " + selectedProfessor.getName() + " has been assigned to the course " + selectedCourse.getTitle());
            }
            else
                System.out.println("\nInvalid professor number.");
        }
        else
            System.out.println("\nInvalid course number.");
    }

    // Handle complaints using the universal list from Complaint.java
    public void HandleComplaints()
    {
        List<Complaint> complaints = Complaint.getComplaints();

        if (complaints.isEmpty())
        {
            System.out.println("\nNo complaints to handle.");
            return;
        }

        Scanner scanner = new Scanner(System.in);
        System.out.println("\nManage Complaints :");

        int index = 1;
        for (Complaint complaint : complaints)
        {
            System.out.println(index + ". " + complaint.getComplaintText() + " | Status: " + complaint.getStatus());
            index++;
        }

        System.out.println("\nEnter the complaint number you want to update (0 to exit): ");
        int complaintNumber = scanner.nextInt();

        if (complaintNumber == 0)
            return;

        if (complaintNumber > 0 && complaintNumber <= complaints.size())
        {
            Complaint selectedComplaint = complaints.get(complaintNumber - 1);
            System.out.println("Current Status : " + selectedComplaint.getStatus());
            System.out.println("Enter new status (Pending/Resolved) : ");
            String newStatus = scanner.next();

            if (newStatus.equalsIgnoreCase("Pending") || newStatus.equalsIgnoreCase("Resolved"))
            {
                selectedComplaint.setStatus(newStatus);
                System.out.println("\nComplaint status updated successfully.");
            }
            else
                System.out.println("\nInvalid status. Please enter either 'Pending' or 'Resolved'.");
        }
        else
            System.out.println("\nInvalid complaint number.");
    }



    // helper functions for MANAGE COURSES
    private void viewAllCourses()
    {
        List<Course> allCourses = Coursecatalog.getAllCourses();

        if (allCourses.isEmpty())
            System.out.println("\nNo courses available.");
        else
        {
            System.out.println("\nAll Courses:");
            for (Course course : allCourses)
                System.out.println(course);
        }
    }

    private void addCourse(Scanner scanner)
    {
        System.out.print("\nEnter Course Code: ");
        String courseCode = scanner.nextLine();
        System.out.print("Enter Course Title: ");
        String title = scanner.nextLine();

        // Get all professors
        List<Professor> professors = Professor.getAllProfessors();

        if (professors.isEmpty())
        {
            System.out.println("\nNo professors available to assign.");
            return;
        }

        // Display all professors
        System.out.println("\nAvailable Professors :");
        int index = 1;
        for (Professor professor : professors)
        {
            System.out.println(index + ". " + professor.getName() + " (" + professor.getEmail() + ")");
            index++;
        }

        System.out.print("\nEnter the professor number to assign : ");
        int professorNumber = scanner.nextInt();
        scanner.nextLine();

        Professor selectedProfessor = null;
        if (professorNumber > 0 && professorNumber <= professors.size())
            selectedProfessor = professors.get(professorNumber - 1);
        else
            System.out.println("\nInvalid professor number. Course will be added without a professor.");

        System.out.print("\nEnter Credits : ");
        int credits = scanner.nextInt();
        scanner.nextLine();

        System.out.print("\nEnter Timings : ");
        String timings = scanner.nextLine();

        // Add course prerequisites
        List<String> prerequisites = new ArrayList<>();
        System.out.println("\nEnter prerequisites (comma-separated, or leave empty) : ");
        String prereqs = scanner.nextLine();
        if (!prereqs.isEmpty())
            prerequisites.addAll(Arrays.asList(prereqs.split("\\s*,\\s*")));

        Course newCourse = new Course(courseCode, title, selectedProfessor, credits, prerequisites, timings);
        Coursecatalog.addCourse(1, newCourse);
        System.out.println("\nCourse added successfully.");
    }

    private void deleteCourse(Scanner scanner)
    {
        System.out.print("\nEnter the Course Code to delete : ");
        String courseCode = scanner.nextLine();

        boolean found = false;

        for (int semester = 1; semester <= 3; semester++)
        {
            List<Course> courses = Coursecatalog.getCoursesForSemester(semester);
            for (Iterator<Course> iterator = courses.iterator(); iterator.hasNext();)
            {
                Course course = iterator.next();
                if (course.getCourseCode().equalsIgnoreCase(courseCode))
                {
                    iterator.remove();
                    System.out.println("\nCourse deleted successfully.");
                    found = true;
                    break;
                }
            }
            if (found)
                break;
        }

        if (!found)
        {
            System.out.println("\nCourse not found.");
        }
    }

    private void handleDeadline(Scanner scanner)
    {
        List<Course> courses = Coursecatalog.getAllCourses();

        if (courses.isEmpty())
        {
            System.out.println("\nNo courses available to assign a deadline.");
            return;
        }

        System.out.println("\nCourses: ");
        int index = 1;
        for (Course course : courses)
        {
            System.out.println(index + ". " + course.getCourseCode() + " - " + course.getTitle());
            index++;
        }

        // Select a course to assign a deadline
        System.out.print("\nEnter the course number to assign a deadline (0 to exit): ");
        int courseNumber = scanner.nextInt();
        scanner.nextLine();

        if (courseNumber == 0)
            return;
        else if (courseNumber > 0 && courseNumber <= courses.size())
        {
            Course selectedCourse = courses.get(courseNumber - 1);

            System.out.print("Enter the deadline in following format (dd-MM-yyyy HH:mm): ");
            String deadlineInput = scanner.nextLine();

            try
            {
                DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm");
                LocalDateTime deadline = LocalDateTime.parse(deadlineInput, formatter);
                selectedCourse.setDeadline(deadline);
                String formattedDeadline = deadline.format(formatter);
                System.out.println("Deadline for course " + selectedCourse.getTitle() + " has been updated to " + formattedDeadline);
            }
            catch (Exception e)
            {
                System.out.println("Invalid date format. Please enter the date in the format dd-MM-yyyy HH:mm");
            }
        }
        else
            System.out.println("\nInvalid course number. Please try again.");
    }

    // helper functions in general
    private void viewAllStudents()
    {
        List<Student> allStudents = Student.getAllStudents();

        if (allStudents.isEmpty())
            System.out.println("\nNo students available.");
        else
        {
            System.out.println("\nAll Students:");
            for (Student student : allStudents)
            {
                System.out.println("Email: " + student.getEmail() + ", Academic Standing: " + student.getAcademicStanding());
            }
        }
    }

    private void updateStudentInformation(Scanner scanner)
    {
        System.out.print("\nEnter the email of the student to update: ");
        String email = scanner.nextLine();

        Student student = Student.getStudentByEmail(email);

        // not a student
        if (student == null)
        {
            System.out.println("Student not found.");
            return;
        }

        System.out.println("\nUpdating information for student with email : " + student.getEmail());
        System.out.println("Current Academic Standing: " + student.getAcademicStanding());

        // Update Email
        System.out.print("\nEnter new Email (or leave empty to keep current) : ");
        String newEmail = scanner.nextLine();
        if (!newEmail.isEmpty())
        {
            student.setEmail(newEmail);
            System.out.println("Email updated successfully.");
        }

        System.out.print("\nEnter new Academic Standing (or leave empty to keep current) : ");
        String newStanding = scanner.nextLine();
        if (!newStanding.isEmpty())
            student.setAcademicStanding(newStanding);

        System.out.println("\nCurrent Contact Details: " + student.getContactDetails());
        System.out.print("Enter new Contact Details (or leave empty to keep current) : ");
        String newContactDetails = scanner.nextLine();
        if (!newContactDetails.isEmpty())
            student.setContactDetails(newContactDetails);

        System.out.println("\nCurrent Grades : ");
        student.viewGrades();
        System.out.println("Choose the course code you would like to update the grade for : ");
        student.ListAllCourses();

        String choice = scanner.nextLine();
        if(!choice.equals(null))
        {
            System.out.print("Enter new grade (or leave empty to keep current) : ");
            String updatedGrade = scanner.nextLine();
            student.updateGrade(choice, updatedGrade);
        }
        else
            System.out.println("Invalid input");

        System.out.println("\nStudent information updated successfully.");
    }
    // end of helper functions

    // misc
    public void showMenu()
    {
        System.out.println();
        System.out.println("-------------------------------------------------------");
        System.out.println("-                   Admin Menu                        -");
        System.out.println("-------------------------------------------------------");
        System.out.println("1. Manage Course Catalog");
        System.out.println("2. Manage Student Records");
        System.out.println("3. Assign Professors to Courses");
        System.out.println("4. Handle Complaints");
        System.out.println("5. Logout");
        System.out.println("-------------------------------------------------------");
    }
}