package project.student;
import java.util.*;
import project.models.*;
import static project.models.Coursecatalog.*;

public class Student extends User
{
    private static List<Student> allStudents = new ArrayList<>();
    private String academicStanding;
    private String contactDetails;
    private int current_semester;
    private int credits;
    private final LinkedList<Course> enrolled_courses;
    private final HashMap<String, String> grades;
    private LinkedList<Complaint> complaints;

    public Student(String email, String password, String type)
    {
        super(email, password, type);
        this.credits = 0;
        this.current_semester = 1;
        this.enrolled_courses = new LinkedList<>();
        this.complaints = new LinkedList<>();
        this.grades = new HashMap<>();
        this.contactDetails = email;
        allStudents.add(this);
    }

    public static List<Student> getAllStudents()
    {
        return new ArrayList<>(allStudents);
    }

    public static Student getStudentByEmail(String email)
    {
        for (Student student : allStudents)
        {
            if (student.getEmail().equalsIgnoreCase(email))
                return student;
        }
        return null;
    }

    public String getAcademicStanding()
    {
        return academicStanding;
    }

    public String getContactDetails()
    {
        return contactDetails;
    }


    public void updateGrade(String courseCode, String grade)
    {
        if (enrolled_courses.stream().anyMatch(course -> course.getCourseCode().equals(courseCode)))
        {
            grades.put(courseCode, grade);
            System.out.println("Grade for " + courseCode + " updated to " + grade);
        }
        else
            System.out.println("You are not enrolled in the course " + courseCode);
    }

    public void viewGrades()
    {
        if (grades.isEmpty())
            System.out.println("No grades available.");
        else
        {
            System.out.println("Your grades:");
            for (Map.Entry<String, String> entry : grades.entrySet())
            {
                System.out.println("Course Code: " + entry.getKey() + ", Grade: " + entry.getValue());
            }
        }
    }

    public void courseMenu()
    {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter the semester you want to view courses for:");
        int semester = scanner.nextInt();

        List<Course> availableCourses = getCoursesForSemester(semester);

        if (availableCourses == null || availableCourses.isEmpty())
            System.out.println("No courses available for semester " + semester);
        else
        {
            System.out.println("Courses available for semester " + semester + ":");
            for (Course course : availableCourses)
            {
                System.out.println("-------------------------------------------------------");
                System.out.println("Course Code: " + course.getCourseCode());
                System.out.println("Course Title: " + course.getTitle());
                System.out.println("Professor: " + course.getProfessor().getName());
                System.out.println("Credits: " + course.getCredits());
                System.out.println("Prerequisites: " + course.getPrerequisites());
                System.out.println("Timings: " + course.getTimings());
                System.out.println("-------------------------------------------------------");
            }
        }
    }

    public void RegisterForCourses()
    {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter the semester you want to register for : ");
        int semester = scanner.nextInt();

        List<Course> availableCourses = Coursecatalog.getCoursesForSemester(semester);

        if (availableCourses == null || availableCourses.isEmpty())
        {
            System.out.println("No courses available for semester " + semester);
            return;
        }

        System.out.println("Available courses for semester " + semester + ":");
        int count = 1;
        for (Course course : availableCourses)
        {
            System.out.println(count + ". " + course.getCourseCode() + " - " + course.getTitle());
            count++;
        }

        System.out.println("Enter the number of the course you want to register for : ");
        int courseIndex = scanner.nextInt();

        if (courseIndex > 0 && courseIndex <= availableCourses.size())
        {
            Course selectedCourse = availableCourses.get(courseIndex - 1);

            // Check if the student is already enrolled in this course
            if (isEnrolledInCourse(selectedCourse.getCourseCode()))
            {
                System.out.println("You are already enrolled in this course.");
                return;
            }

            // haven't registered for 20 credits yet
            if (this.credits + selectedCourse.getCredits() > 20)
            {
                System.out.println("You cannot register for more than 20 credits. Your quota is full.");
                return;
            }

            // pre req check
            List<String> prerequisites = selectedCourse.getPrerequisites();
            boolean meetsPrerequisites = true;

            if (!prerequisites.isEmpty())
            {
                for (String prereq : prerequisites)
                {
                    if (!hasCompletedCourse(prereq))
                    {
                        meetsPrerequisites = false;
                        System.out.println("You do not meet the prerequisite : " + prereq);
                    }
                }
            }

            if (meetsPrerequisites)
            {
                enrolled_courses.add(selectedCourse);
                this.credits += selectedCourse.getCredits();
                selectedCourse.enrollStudent(this);
                System.out.println("You have successfully registered for " + selectedCourse.getTitle());
            }
            else
                System.out.println("You cannot register for this course due to unmet prerequisites");
        }
        else
            System.out.println("Invalid selection");
    }

    // Helper method to check if a student is already enrolled in a course
    private boolean isEnrolledInCourse(String courseCode)
    {
        for (Course course : enrolled_courses)
        {
            if (course.getCourseCode().equals(courseCode))
                return true;
        }
        return false;
    }

    // Helper to check if pre req is met
    private boolean hasCompletedCourse(String courseCode)
    {
        for (Course course : enrolled_courses)
        {
            if (course.getCourseCode().equals(courseCode))
            {
                String grade = grades.get(courseCode);
                return grade != null && !grade.equals("Not graded yet");
            }
        }
        return false;
    }

    public void ListAllCourses()
    {
        if(enrolled_courses.isEmpty())
            System.out.println("You haven't registered for any courses yet");
        else
        {
            System.out.println("Your enrolled courses are : ");
            for (Course course : enrolled_courses)
                System.out.println(course);
        }
    }

    public void ViewSchedule()
    {
        if (enrolled_courses.isEmpty())
        {
            System.out.println("You are not enrolled in any courses");
            return;
        }

        System.out.println("Your weekly course schedule :");
        for (Course course : enrolled_courses)
        {
            System.out.println("-------------------------------------------------------");
            System.out.println("Course Title: " + course.getTitle());
            System.out.println("Course Code: " + course.getCourseCode());
            System.out.println("Professor: " + course.getProfessor().getEmail());
            System.out.println("Timings: " + course.getTimings());
            System.out.println("-------------------------------------------------------");
        }
    }

    public void TrackAcademicProgress()
    {
        if (enrolled_courses.isEmpty())
            System.out.println("You are not enrolled in any courses");
        else if (grades.isEmpty())
            System.out.println("Grades aren't available yet");
        else
        {
            System.out.println("Your academic progress :");

            double totalGradePoints = 0.0;
            double totalCredits = 0.0;
            List<Double> currentSemesterGradePoints = new ArrayList<>();
            int currentSemesterCredits = 0;

            for (Course course : enrolled_courses)
            {
                String gradeStr = grades.getOrDefault(course.getCourseCode(), "Not graded yet");
                System.out.println(course.getCourseCode() + " - " + course.getTitle() + ": " + gradeStr);

                if (!gradeStr.equals("Not graded yet"))
                {
                    try
                    {
                        double grade = Double.parseDouble(gradeStr);
                        if (grade < 0 || grade > 10)
                        {
                            System.out.println("Invalid grade for " + course.getTitle() + ". Must be between 0 and 10.");
                            continue;
                        }

                        totalGradePoints += grade * course.getCredits();
                        totalCredits += course.getCredits();
                        currentSemesterGradePoints.add(grade);
                        currentSemesterCredits += course.getCredits();
                    }
                    catch (NumberFormatException e)
                    {
                        System.out.println("Invalid grade format for " + course.getTitle());
                    }
                }
            }

            if (totalCredits > 0)
            {
                double cgpa = totalGradePoints / totalCredits;
                System.out.println("Your current CGPA is : " + String.format("%.2f", cgpa));
            }

            if (currentSemesterCredits > 0)
            {
                double sgpa = currentSemesterGradePoints.stream().mapToDouble(gp -> gp).sum() / currentSemesterCredits;
                System.out.println("Your SGPA for the current semester is : " + String.format("%.2f", sgpa));
            }
        }
    }

    public void DropCourses()
    {
        if(enrolled_courses.isEmpty())
            System.out.println("You are not enrolled for any courses at this moment ! ");
        else
        {
            System.out.println("Your enrolled courses are : ");
            int count = 1;
            for (Course course : enrolled_courses)
            {
                System.out.println(count + ". " + course.getTitle());
                count++;
            }

            Scanner scanner = new Scanner(System.in);
            System.out.println("Enter the number of the course you want to drop : ");
            int courseIndex = scanner.nextInt();

            if (courseIndex > 0 && courseIndex <= enrolled_courses.size())
            {
                Course courseToDrop = enrolled_courses.get(courseIndex - 1);

                courseToDrop.getEnrolledStudents().remove(this);

                this.credits -= courseToDrop.getCredits();

                enrolled_courses.remove(courseToDrop);

                System.out.println("You have successfully dropped the course : " + courseToDrop.getTitle());
            }
            else
                System.out.println("Invalid course selection");
        }
    }

    public void SubmitComplaint()
    {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter your complaint : ");
        String complaintText = scanner.nextLine();

        if (complaintText.trim().isEmpty())
            System.out.println("Invalid complaint !");
        else
        {
            Complaint newComplaint = new Complaint(complaintText);
            Complaint.addComplaint(newComplaint);
            complaints.add(newComplaint);
            System.out.println("Your complaint has been successfully submitted.");
        }
    }

    public void ViewComplaints()
    {
        if(complaints.isEmpty())
            System.out.println("Complaint list is empty");
        else
        {
            System.out.println("Your complaints are:");
            for (Complaint complaint : complaints)
            {
                System.out.println("-------------------------------------------------------");
                System.out.println("Complaint: " + complaint.getText());
                System.out.println("Status: " + complaint.getStatus());
                System.out.println("-------------------------------------------------------");
            }
        }
    }

    public void showMenu()
    {
        System.out.println("-------------------------------------------------------");
        System.out.println("-                   Student Menu                      -");
        System.out.println("-------------------------------------------------------");
        System.out.println("1. View Available Courses");
        System.out.println("2. Register for Courses");
        System.out.println("3. Track All Course");
        System.out.println("4. View Schedule");
        System.out.println("5. Track Academic Progress");
        System.out.println("6. Drop Courses");
        System.out.println("7. Submit Complaints");
        System.out.println("8. View Complaints");
        System.out.println("9. Logout");
        System.out.println("-------------------------------------------------------");
    }

    public void setAcademicStanding(String newStanding) {
    }

    public void setContactDetails(String newContactDetails) {
    }

    public void setEmail(String newEmail)
    {
        if (newEmail == null || newEmail.isEmpty())
        {
            System.out.println("Email cannot be null or empty.");
            return;
        }

        // Simple email validation
        if (newEmail.contains("@") && newEmail.indexOf("@") > 0 && newEmail.lastIndexOf(".") > newEmail.indexOf("@") + 1)
        {
            this.contactDetails = newEmail;
            System.out.println("Email updated to: " + newEmail);
        }
        else
            System.out.println("Invalid email format.");
    }
}