package project.main;

import java.util.*;
import project.admin.Admin;
import project.models.User;
import project.professor.Professor;
import project.student.Student;

public class erp
{
    static ArrayList<Student> Students = new ArrayList<>();
    public static ArrayList<Professor> Professors = new ArrayList<>();
    static ArrayList<Admin> Admins = new ArrayList<>();

    static HashMap<String, User> Users = new HashMap<>();

    public static void main(String[] args)
    {
        // adding some default students/professors/admins
        Admin Default_admin = new Admin("Default_admin@iiitd.ac.in", "1234", "Admin");
        Professor Default_professor = new Professor("Default_professor@iiitd.ac.in", "1234", "Professor");
        Student Default_student = new Student("Default_student@iiitd.ac.in", "1234", "Student");

        Admin admin1 = new Admin("admin1@iiitd.ac.in", "1234", "Admin");
        Admin admin2 = new Admin("admin2@iiitd.ac.in", "1234", "Admin");
        Admin admin3 = new Admin("admin3@iiitd.ac.in", "1234", "Admin");

        Admins.add(admin1);
        Admins.add(admin2);
        Admins.add(admin3);

        Professor prof1 = new Professor("prof1@iiitd.ac.in", "1234", "Professor");
        Professor prof2 = new Professor("prof2@iiitd.ac.in", "1234", "Professor");
        Professor prof3 = new Professor("prof3@iiitd.ac.in", "1234", "Professor");
        Professor prof4 = new Professor("bnj@iiitd.ac.in","1234","Professor");
        Professor prof5 = new Professor("bnj@iiitd.ac.in", "1234", "Professor");
        Professor prof6 = new Professor("pvb@iiitd.ac.in", "1234", "Professor");
        Professor prof7 = new Professor("pcm@iiitd.ac.in", "1234", "Professor");
        Professor prof8 = new Professor("rrs@iiitd.ac.in", "1234", "Professor");
        Professor prof9 = new Professor("smc@iiitd.ac.in", "1234", "Professor");
        Professor prof10 = new Professor("ojs@iiitd.ac.in", "1234", "Professor");
        Professor prof11 = new Professor("tmt@iiitd.ac.in", "1234", "Professor");
        Professor prof12 = new Professor("kkk@iiitd.ac.in", "1234", "Professor");
        Professor prof13 = new Professor("sdb@iiitd.ac.in", "1234", "Professor");
        Professor prof14 = new Professor("sgc@iiitd.ac.in", "1234", "Professor");
        Professor prof15 = new Professor("prof1@iiitd.ac.in", "1234","Professor");
        Professor prof16 = new Professor("prof2@iiitd.ac.in", "1234","Professor");

        Professors.add(prof1);
        Professors.add(prof2);
        Professors.add(prof3);
        Professors.add(prof4);
        Professors.add(prof5);
        Professors.add(prof6);
        Professors.add(prof7);
        Professors.add(prof8);
        Professors.add(prof9);
        Professors.add(prof10);
        Professors.add(prof11);
        Professors.add(prof12);
        Professors.add(prof13);
        Professors.add(prof14);
        Professors.add(prof15);
        Professors.add(prof16);

        Student student1 = new Student("student1@iiitd.ac.in", "1234", "Student");
        Student student2 = new Student("student2@iiitd.ac.in", "1234", "Student");
        Student student3 = new Student("student3@iiitd.ac.in", "1234", "Student");

        Students.add(student1);
        Students.add(student2);
        Students.add(student3);

        Users.put(admin1.getEmail(), admin1);
        Users.put(admin2.getEmail(), admin2);
        Users.put(admin3.getEmail(), admin3);
        Users.put(student1.getEmail(), student1);
        Users.put(student2.getEmail(), student2);
        Users.put(student3.getEmail(), student3);
        Users.put(prof1.getEmail(), prof1);
        Users.put(prof2.getEmail(), prof2);
        Users.put(prof3.getEmail(), prof3);
        Users.put(prof4.getEmail(), prof4);
        Users.put(prof5.getEmail(), prof5);
        Users.put(prof6.getEmail(), prof6);
        Users.put(prof7.getEmail(), prof7);
        Users.put(prof8.getEmail(), prof8);
        Users.put(prof9.getEmail(), prof9);
        Users.put(prof10.getEmail(), prof10);
        Users.put(prof11.getEmail(), prof11);
        Users.put(prof12.getEmail(), prof12);
        Users.put(Default_admin.getEmail(), Default_admin);
        Users.put(Default_professor.getEmail(), Default_professor);
        Users.put(Default_student.getEmail(), Default_student);

        Admins.add(Default_admin);
        Professors.add(Default_professor);
        Students.add(Default_student);

        Scanner scanner = new Scanner(System.in);

        while(true)
        {
            mainmenu1();
            String select = scanner.nextLine();

            switch (select)
            {
                case "1":
                    mainmenu2();
                    loginmenu();
                    break;
                case "2":
                    mainmenu3();
                    signupmenu();
                    break;
                case "3":
                    System.out.println("Successfully exited");
                    return;
                default:
                    System.out.println("Please choose a valid option");
                    break;
            }
        }
    }

    public static void loginmenu()
    {
        Scanner scanner = new Scanner(System.in);
        String select = scanner.nextLine();

        switch(select)
        {
            case "1":
                authenticate_user("Student");
                break;
            case "2":
                authenticate_user("Professor");
                break;
            case "3":
                authenticate_user("Admin");
                break;
            case "4":
                return;
            default:
                System.out.println("Please choose a valid option");
                break;
        }
    }

    public static void signupmenu()
    {
        Scanner scanner = new Scanner(System.in);
        String select = scanner.nextLine();
        String email = "";
        String password = "";

        if(select.equals("1") || select.equals("2") || select.equals("3"))
        {
            System.out.println("Enter your college email id");
            email = scanner.nextLine();

            if(Users.containsKey(email))
            {
                System.out.println("User with this email already exists. Please try logging in");
                return;
            }
            if (select.equals("1") || select.equals("2"))
            {
                System.out.println("Choose your Password");
                password = scanner.nextLine();
            }
        }

        switch(select)
        {
            case "1":
                Student newStudent = new Student(email, password, "Student");
                Students.add(newStudent);
                Users.put(email, newStudent);
                System.out.println("Signup Successful ! you may login now");
                break;
            case "2":
                Professor newProfessor = new Professor(email, password, "Professor");
                Professors.add(newProfessor);
                Users.put(email, newProfessor);
                System.out.println("Signup Successful ! you may login now");
                break;
            case "3":
                System.out.println("The password for admin is set by default");
                Admin newAdmin = new Admin(email, "1234", "Admin");
                Admins.add(newAdmin);
                Users.put(email, newAdmin);
                System.out.println("Signup Successful ! you may login now");
                break;
            case "4":
                return;
            default:
                System.out.println("Please choose a valid option");
                break;
        }
    }

    // to check whether email exists in directory and if it does then whether the entered password matches or not
    public static void authenticate_user(String userType)
    {
        Scanner scanner = new Scanner(System.in);
        int attempts = 5;

        while (attempts > 0)
        {
            System.out.println("Enter your email id (or type 'back' to go to the previous menu): ");
            String email = scanner.nextLine();

            if (email.equalsIgnoreCase("back"))
                return;

            System.out.println("Enter your password: ");
            String password = scanner.nextLine();

            if (Users.containsKey(email))
            {
                User user = Users.get(email);

                if (user.authenticate(password, userType))
                {
                    System.out.println("Login Successful");

                    if (user instanceof Student verified_student)
                        handleStudentMenu(verified_student);
                    else if (user instanceof Professor verified_prof)
                        handleProfessorMenu(verified_prof);
                    else if (user instanceof Admin verified_admin)
                        handleAdminMenu(verified_admin);
                    return;
                }
                else
                    System.out.println("Incorrect Password, Try Again");
            }
            else
                System.out.println("Incorrect Email, Try again");

            attempts--;
            System.out.println("Attempts remaining: " + attempts);
        }

        System.out.println("Too many failed attempts");
    }

    public static void handleAdminMenu(Admin verified_admin)
    {
        Scanner scanner = new Scanner(System.in);
        String query = "";

        while(!query.equals("5"))
        {
            verified_admin.showMenu();
            query = scanner.nextLine();

            switch (query)
            {
                case "1":
                    verified_admin.ManageCourseCatalog();
                    break;
                case "2":
                    verified_admin.ManageStudentRecords();
                    break;
                case "3":
                    verified_admin.AssignProfessor();
                    break;
                case "4":
                    verified_admin.HandleComplaints();
                    break;
                case "5":
                    System.out.println("Successfully Logged Out ! ");
                    return;
                default:
                    System.out.println("Please choose a valid input");
                    break;
            }
        }
    }

    public static void handleProfessorMenu(Professor verified_prof)
    {
        Scanner scanner = new Scanner(System.in);
        String query = "";

        while(!query.equals("3"))
        {
            verified_prof.showMenu();
            query = scanner.nextLine();

            switch (query)
            {
                case "1":
                    verified_prof.ManageCourses();
                    break;
                case "2":
                    verified_prof.ViewEnrolledStudents();
                    break;
                case "3":
                    System.out.println("Successfully Logged Out ! ");
                    return;
                default:
                    System.out.println("Please choose a valid input");
                    break;
            }
        }
    }

    public static void handleStudentMenu(Student verified_student)
    {
        Scanner scanner = new Scanner(System.in);
        String query = "";

        while (!query.equals("9"))
        {
            verified_student.showMenu();
            query = scanner.nextLine();

            switch (query)
            {
                case "1":
                    verified_student.courseMenu();
                    break;
                case "2":
                    verified_student.RegisterForCourses();
                    break;
                case "3":
                    verified_student.ListAllCourses();
                    break;
                case "4":
                    verified_student.ViewSchedule();
                    break;
                case "5":
                    verified_student.TrackAcademicProgress();
                    break;
                case "6":
                    verified_student.DropCourses();
                    break;
                case "7":
                    verified_student.SubmitComplaint();
                    break;
                case "8":
                    verified_student.ViewComplaints();
                    break;
                case "9":
                    System.out.println("Successfully Logged Out ! ");
                    return;
                default:
                    System.out.println("Please choose a valid option");
                    break;
            }
        }
    }

    public static void mainmenu1()
    {
        System.out.println("-------------------------------------------------------");
        System.out.println("-                      Main Menu                      -");
        System.out.println("-------------------------------------------------------");
        System.out.println("Welcome to ERP");
        System.out.println("1. Login");
        System.out.println("2. Signup");
        System.out.println("3. Exit");
        System.out.println("-------------------------------------------------------");
    }

    public static void mainmenu2()
    {
        System.out.println("-------------------------------------------------------");
        System.out.println("-                     Login Menu                      -");
        System.out.println("-------------------------------------------------------");
        System.out.println("1. Login as Student");
        System.out.println("2. Login as Professor");
        System.out.println("3. Login as Administrator");
        System.out.println("4. Go Back");
        System.out.println("-------------------------------------------------------");
    }

    public static void mainmenu3()
    {
        System.out.println("-------------------------------------------------------");
        System.out.println("-                    SignUp Menu                      -");
        System.out.println("-------------------------------------------------------");
        System.out.println("1. Signup as Student");
        System.out.println("2. Signup as Professor");
        System.out.println("3. Signup as Administrator");
        System.out.println("4. Go Back");
        System.out.println("-------------------------------------------------------");
    }
}