package project.professor;

import project.models.*;
import project.student.Student;
import java.util.*;

public class Professor extends User
{
    private LinkedList<Course> courses;

    public Professor(String email, String password, String type)
    {
        super(email, password, type);
        this.courses = new LinkedList<>();
    }

    public void ManageCourses()
    {
        Scanner scanner = new Scanner(System.in);

        while (true)
        {
            System.out.println("Manage Courses:");
            if (courses.isEmpty())
            {
                System.out.println("You aren't teaching any courses at the moment.");
                return;
            }

            // Display all courses
            for (int i = 0; i < courses.size(); i++)
            {
                Course course = courses.get(i);
                System.out.println((i + 1) + ". " + course.getTitle() + " (" + course.getCourseCode() + ")");
            }

            System.out.println("Enter the course number to manage (0 to exit): ");
            int courseNumber = scanner.nextInt();
            scanner.nextLine();

            if (courseNumber == 0)
                return;

            if (courseNumber > 0 && courseNumber <= courses.size())
            {
                Course selectedCourse = courses.get(courseNumber - 1);
                manageCourseDetails(selectedCourse, scanner);
            }
            else
                System.out.println("Invalid course number.");
        }
    }

    private void manageCourseDetails(Course course, Scanner scanner)
    {
        while (true)
        {
            System.out.println("Managing Course: " + course.getTitle());
            System.out.println("1. Update Syllabus");
            System.out.println("2. Update Class Timings");
            System.out.println("3. Update Credits");
            System.out.println("4. Update Prerequisites");
            System.out.println("5. Update Enrollment Limit");
            System.out.println("6. Back to Course List");
            System.out.print("Choose an option: ");

            // Trim whitespace around each part
            int option = scanner.nextInt();
            scanner.nextLine();

            switch (option)
            {
                case 1:
                    System.out.print("Enter new syllabus: ");

                    // Trim whitespace
                    String syllabus = scanner.nextLine();
                    course.setSyllabus(syllabus);

                    System.out.println("Syllabus updated successfully.");
                    break;
                case 2:
                    System.out.print("Enter new class timings: ");

                    String timings = scanner.nextLine();
                    course.setTimings(timings);

                    System.out.println("Class timings updated successfully.");
                    break;
                case 3:
                    System.out.print("Enter new credits: ");

                    int credits = scanner.nextInt();
                    scanner.nextLine();

                    course.setCredits(credits);
                    System.out.println("Credits updated successfully.");
                    break;
                case 4:
                    System.out.print("Enter new prerequisites (comma-separated): ");
                    String prereqs = scanner.nextLine();

                    List<String> prerequisites = new ArrayList<>();
                    String[] parts = prereqs.split(",");

                    for (String part : parts)
                        prerequisites.add(part.trim());

                    course.setPrerequisites(prerequisites);

                    System.out.println("Prerequisites updated successfully.");
                    break;
                case 5:
                    System.out.print("Enter new enrollment limit: ");

                    int enrollmentLimit = scanner.nextInt();
                    scanner.nextLine();

                    course.setEnrollmentLimit(enrollmentLimit);
                    System.out.println("Enrollment limit updated successfully.");
                    break;
                case 6:
                    return;
                default:
                    System.out.println("Invalid option. Please try again.");
            }
        }
    }

    public void ViewEnrolledStudents()
    {
        if (courses.isEmpty())
            System.out.println("You aren't teaching any courses at the moment.");
        else
        {
            for (Course course : courses)
            {
                List<Student> enrolledStudents = course.getEnrolledStudents();

                System.out.println("Course: " + course.getTitle() + " (" + course.getCourseCode() + ")");
                if (enrolledStudents.isEmpty())
                    System.out.println("No students are enrolled in this course.");
                else
                {
                    System.out.println("Enrolled Students : ");
                    for (Student student : enrolledStudents)
                    {
                        System.out.println("---------------------------------------");
                        System.out.println("Email: " + student.getEmail());
                        System.out.println("Academic Standing: " + student.getAcademicStanding());
                        System.out.println("Contact Details: " + student.getContactDetails());
                        System.out.println("---------------------------------------");
                    }
                }
                System.out.println();
            }
        }
    }

    public void addCourse(Course course)
    {
        courses.add(course);
    }

    public static List<Professor> getAllProfessors() {
        return new ArrayList<>(project.main.erp.Professors);
    }

    public String getName()
    {
        return getEmail();
    }

    public void showMenu()
    {
        System.out.println("-------------------------------------------------------");
        System.out.println("-                  Professor Menu                     -");
        System.out.println("-------------------------------------------------------");
        System.out.println("1. Manage Courses");
        System.out.println("2. View Enrolled Students");
        System.out.println("3. Logout");
        System.out.println("-------------------------------------------------------");
    }

    public void removeCourse(Course selectedCourse) {
        courses.remove(selectedCourse);
    }
}