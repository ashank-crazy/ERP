package project.admin;

import java.util.*;
import project.models.*;
import project.professor.Professor;
import project.student.Student;

public class Admin extends User
{
    public Admin(String email, String password, String type)
    {
        super(email, password, type);
    }

    public void ManageCourseCatalog()
    {
        Scanner scanner = new Scanner(System.in);

        while (true)
        {
            System.out.println("Manage Course Catalog :");
            System.out.println("1. View All Courses");
            System.out.println("2. Add Course");
            System.out.println("3. Delete Course");
            System.out.println("4. Return to Menu");
            System.out.print("Choose an option : ");
            int option = scanner.nextInt();
            scanner.nextLine();

            switch (option)
            {
                case 1:
                    viewAllCourses();
                    break;
                case 2:
                    addCourse(scanner);
                    break;
                case 3:
                    deleteCourse(scanner);
                    break;
                case 4:
                    return;
                default:
                    System.out.println("Invalid option. Please try again.");
            }
        }
    }

    private void viewAllCourses()
    {
        List<Course> allCourses = Coursecatalog.getAllCourses();

        if (allCourses.isEmpty())
            System.out.println("No courses available.");
        else
        {
            System.out.println("All Courses:");
            for (Course course : allCourses)
                System.out.println(course);
        }
    }

    public void addCourse(Scanner scanner)
    {
        System.out.print("Enter Course Code: ");
        String courseCode = scanner.nextLine();
        System.out.print("Enter Course Title: ");
        String title = scanner.nextLine();

        // Get all professors
        List<Professor> professors = Professor.getAllProfessors();

        if (professors.isEmpty())
        {
            System.out.println("No professors available to assign.");
            return;
        }

        // Display all professors
        System.out.println("Available Professors:");
        int index = 1;
        for (Professor professor : professors)
        {
            System.out.println(index + ". " + professor.getName() + " (" + professor.getEmail() + ")");
            index++;
        }

        System.out.print("Enter the professor number to assign: ");
        int professorNumber = scanner.nextInt();
        scanner.nextLine();

        Professor selectedProfessor = null;
        if (professorNumber > 0 && professorNumber <= professors.size())
            selectedProfessor = professors.get(professorNumber - 1);
        else
            System.out.println("Invalid professor number. Course will be added without a professor.");

        System.out.print("Enter Credits: ");
        int credits = scanner.nextInt();
        scanner.nextLine();

        System.out.print("Enter Timings: ");
        String timings = scanner.nextLine();

        // Add course prerequisites
        List<String> prerequisites = new ArrayList<>();
        System.out.println("Enter prerequisites (comma-separated, or leave empty): ");
        String prereqs = scanner.nextLine();
        if (!prereqs.isEmpty())
            prerequisites.addAll(Arrays.asList(prereqs.split("\\s*,\\s*")));

        Course newCourse = new Course(courseCode, title, selectedProfessor, credits, prerequisites, timings);
        Coursecatalog.addCourse(1, newCourse);
        System.out.println("Course added successfully.");
    }

    private void deleteCourse(Scanner scanner)
    {
        System.out.print("Enter the Course Code to delete: ");
        String courseCode = scanner.nextLine();

        boolean found = false;

        for (int semester = 1; semester <= 3; semester++)
        {
            List<Course> courses = Coursecatalog.getCoursesForSemester(semester);
            for (Iterator<Course> iterator = courses.iterator(); iterator.hasNext();)
            {
                Course course = iterator.next();
                if (course.getCourseCode().equalsIgnoreCase(courseCode))
                {
                    iterator.remove();
                    System.out.println("Course deleted successfully.");
                    found = true;
                    break;
                }
            }
            if (found)
                break;
        }

        if (!found)
        {
            System.out.println("Course not found.");
        }
    }

    public void ManageStudentRecords()
    {
        Scanner scanner = new Scanner(System.in);

        while (true)
        {
            System.out.println("Manage Student Records :");
            System.out.println("1. View All Students");
            System.out.println("2. Update Student Information");
            System.out.println("3. Return to Menu");
            System.out.print("Choose an option : ");
            int option = scanner.nextInt();
            scanner.nextLine();

            switch (option)
            {
                case 1:
                    viewAllStudents();
                    break;
                case 2:
                    updateStudentInformation(scanner);
                    break;
                case 3:
                    return;
                default:
                    System.out.println("Invalid option. Please try again.");
            }
        }
    }

    private void viewAllStudents()
    {
        List<Student> allStudents = Student.getAllStudents();

        if (allStudents.isEmpty())
            System.out.println("No students available.");
        else
        {
            System.out.println("All Students:");
            for (Student student : allStudents)
            {
                System.out.println("Email: " + student.getEmail() +
                        ", Academic Standing: " + student.getAcademicStanding());
            }
        }
    }

    private void updateStudentInformation(Scanner scanner)
    {
        System.out.print("Enter the email of the student to update: ");
        String email = scanner.nextLine();

        Student student = Student.getStudentByEmail(email);

        if (student == null)
        {
            System.out.println("Student not found.");
            return;
        }

        System.out.println("Updating information for student with email : " + student.getEmail());
        System.out.println("Current Academic Standing: " + student.getAcademicStanding());

        // Update Email
        System.out.print("Enter new Email (or leave empty to keep current) : ");
        String newEmail = scanner.nextLine();
        if (!newEmail.isEmpty())
        {
            student.setEmail(newEmail);
            System.out.println("Email updated successfully.");
        }

        System.out.print("Enter new Academic Standing (or leave empty to keep current) : ");
        String newStanding = scanner.nextLine();
        if (!newStanding.isEmpty())
            student.setAcademicStanding(newStanding);

        System.out.println("Current Contact Details: " + student.getContactDetails());
        System.out.print("Enter new Contact Details (or leave empty to keep current) : ");
        String newContactDetails = scanner.nextLine();
        if (!newContactDetails.isEmpty())
            student.setContactDetails(newContactDetails);

        System.out.println("Current Grades : ");
        student.viewGrades();
        System.out.println("Choose the course you would like to update the grade for : ");
        student.ListAllCourses();

        String choice = scanner.nextLine();
        if(!choice.equals(null))
        {
            System.out.print("Enter new grade (or leave empty to keep current) : ");
            String updatedGrade = scanner.nextLine();
            student.updateGrade(choice, updatedGrade);
        }
        else
            System.out.println("Invalid input");

        System.out.println("Student information updated successfully.");
    }


    public void AssignProfessor()
    {
        Scanner scanner = new Scanner(System.in);

        // Get all courses from the catalog
        List<Course> courses = Coursecatalog.getAllCourses();

        // If no courses are available
        if (courses.isEmpty())
        {
            System.out.println("No courses available to assign professors.");
            return;
        }

        // Display all courses
        System.out.println("Courses : ");
        int index = 1;
        for (Course course : courses)
        {
            System.out.println(index + ". " + course.getCourseCode() + " - " + course.getTitle() +
                    " | Current Professor : " + (course.getProfessor() != null ? course.getProfessor().getName() : "None"));
            index++;
        }

        // Select a course to assign a professor
        System.out.println("Enter the course number you want to assign a professor to (0 to exit) : ");
        int courseNumber = scanner.nextInt();

        if (courseNumber == 0)
            return;

        if (courseNumber > 0 && courseNumber <= courses.size())
        {
            Course selectedCourse = courses.get(courseNumber - 1);

            // Get all professors again
            List<Professor> professors = Professor.getAllProfessors();

            // If no professors available
            if (professors.isEmpty())
            {
                System.out.println("No professors available.");
                return;
            }

            // Display all professors again
            System.out.println("Available Professors:");
            index = 1;
            for (Professor professor : professors)
            {
                System.out.println(index + ". " + professor.getName() + " (" + professor.getEmail() + ")");
                index++;
            }

            System.out.println("Enter the professor number to assign (0 to exit): ");
            int professorNumber = scanner.nextInt();

            if (professorNumber == 0)
                return;

            if (professorNumber > 0 && professorNumber <= professors.size()) {
                Professor selectedProfessor = professors.get(professorNumber - 1);

                if (selectedCourse.getProfessor() != null)
                {
                    selectedCourse.getProfessor().removeCourse(selectedCourse);
                }

                selectedCourse.setProfessor(selectedProfessor);
                System.out.println("Professor " + selectedProfessor.getName() + " has been assigned to the course " + selectedCourse.getTitle());
            }
            else
                System.out.println("Invalid professor number.");
        }
        else
            System.out.println("Invalid course number.");
    }

    // Handle complaints using the universal list from Complaint.java
    public void HandleComplaints()
    {
        List<Complaint> complaints = Complaint.getComplaints();

        if (complaints.isEmpty())
        {
            System.out.println("No complaints to handle.");
            return;
        }

        Scanner scanner = new Scanner(System.in);
        System.out.println("Manage Complaints :");

        int index = 1;
        for (Complaint complaint : complaints)
        {
            System.out.println(index + ". " + complaint.getComplaintText() + " | Status: " + complaint.getStatus());
            index++;
        }

        System.out.println("Enter the complaint number you want to update (0 to exit): ");
        int complaintNumber = scanner.nextInt();

        if (complaintNumber == 0)
            return;

        if (complaintNumber > 0 && complaintNumber <= complaints.size())
        {
            Complaint selectedComplaint = complaints.get(complaintNumber - 1);
            System.out.println("Current Status : " + selectedComplaint.getStatus());
            System.out.println("Enter new status (Pending/Resolved) : ");
            String newStatus = scanner.next();

            if (newStatus.equalsIgnoreCase("Pending") || newStatus.equalsIgnoreCase("Resolved"))
            {
                selectedComplaint.setStatus(newStatus);
                System.out.println("Complaint status updated successfully.");
            }
            else
                System.out.println("Invalid status. Please enter either 'Pending' or 'Resolved'.");
        }
        else
            System.out.println("Invalid complaint number.");
    }

    public void showMenu()
    {
        System.out.println("-------------------------------------------------------");
        System.out.println("-                   Admin Menu                        -");
        System.out.println("-------------------------------------------------------");
        System.out.println("1. Manage Course Catalog");
        System.out.println("2. Manage Student Records");
        System.out.println("3. Assign Professors to Courses");
        System.out.println("4. Handle Complaints");
        System.out.println("5. Logout");
        System.out.println("-------------------------------------------------------");
    }
}