package project.models;

import project.professor.Professor;
import java.util.*;

public class Coursecatalog
{
    private static final Map<Integer, List<Course>> coursesBySemester = new HashMap<>();

    static
    {
        List<Professor> professors = Professor.getAllProfessors();

        // some default professors
        Professor prof1 = professors.get(0);
        Professor prof2 = professors.get(1);
        Professor prof3 = professors.get(2);
        Professor prof4 = professors.get(3);
        Professor prof5 = professors.get(4);
        Professor prof6 = professors.get(5);
        Professor prof7 = professors.get(6);
        Professor prof8 = professors.get(7);
        Professor prof9 = professors.get(8);
        Professor prof10 = professors.get(9);

        coursesBySemester.put(1, new ArrayList<>(Arrays.asList(
                new Course("CSE101", "Introduction to Programming", prof1, 4, Collections.emptyList(), "MW 8:00-9:30"),
                new Course("ECE101", "Digital Circuits", prof2, 4, Collections.emptyList(), "TTh 11:00-12:00"),
                new Course("SSH101", "Communication Skills", prof3, 4, Collections.emptyList(), "Th 3:00-6:00"),
                new Course("DES101", "Human Computer Interaction", prof4, 4, Collections.emptyList(), "MW 10:00-11:30"),
                new Course("MTH101", "Linear Algebra", prof5, 4, Collections.emptyList(), "TW 10:00-11:30")
        )));

        coursesBySemester.put(2, new ArrayList<>(Arrays.asList(
                new Course("CSE201", "Data Structures and Algorithms", prof6, 4, Arrays.asList("CSE101"), "TTh 10:00-11:30"),
                new Course("ECE201", "Basic Electronics", prof7, 4, Collections.emptyList(), "MWF 2:00-3:00"),
                new Course("SSH201", "Money and Banking", prof8, 4, Collections.emptyList(), "TTh 3:00-4:30"),
                new Course("ECE102", "Computer Organization", prof9, 4, Collections.emptyList(), "MW 8:00-9:30"),
                new Course("MTH201", "Probability and Statistics", prof10, 4, Collections.emptyList(), "ThF 10:00-11:30")
        )));

        coursesBySemester.put(3, new ArrayList<>(Arrays.asList(
                new Course("CSE301", "Advanced Programming", prof3, 4, Arrays.asList("CSE201"), "TTh 10:00-11:30"),
                new Course("ECE301", "Signals and Systems", prof2, 4, Collections.emptyList(), "MWF 2:00-3:00"),
                new Course("ECE302", "Circuit Theory and Devices", prof6, 4, Collections.emptyList(), "TTh 3:00-4:30"),
                new Course("ECE303", "Embedded Logic Design", prof5, 4, Collections.emptyList(), "MW 8:00-9:30"),
                new Course("MTH301", "Multivariate Calculus", prof10, 4, Collections.emptyList(), "ThF 10:00-11:30")
        )));
    }

    public static List<Course> getCoursesForSemester(int semester)
    {
        return coursesBySemester.getOrDefault(semester, new ArrayList<>());
    }

    public static List<Course> getAllCourses()
    {
        List<Course> allCourses = new ArrayList<>();

        for (List<Course> courses : coursesBySemester.values())
            allCourses.addAll(courses);

        return allCourses;
    }

    public static void addCourse(int semester, Course course)
    {
        coursesBySemester.computeIfAbsent(semester, k -> new ArrayList<>()).add(course);
    }

    public static void removeCourse(int semester, Course course)
    {
        List<Course> courses = coursesBySemester.get(semester);
        if (courses != null) {
            courses.remove(course);
        }
    }
}