package project.models;

import project.professor.Professor;
import project.student.Student;

import java.util.*;

public class Course
{
    private final String courseCode;
    private final String title;
    private Professor professor; 
    private int credits;
    private String timings; 
    private List<String> prerequisites;
    private final List<Student> enrolledStudents;
    private int enrollmentLimit; 
    private String syllabus;

    public Course(String courseCode, String title, Professor professor, int credits, List<String> prerequisites, String timings)
    {
        this.courseCode = courseCode;
        this.title = title;
        this.professor = professor;
        this.credits = credits;
        this.prerequisites = prerequisites;
        this.timings = timings;
        this.enrolledStudents = new ArrayList<>();
        this.enrollmentLimit = Integer.MAX_VALUE; 
    }

    public List<Student> getEnrolledStudents()
    {
        return enrolledStudents;
    }

    public void enrollStudent(Student student)
    {
        if (enrolledStudents.size() < enrollmentLimit)
            enrolledStudents.add(student);
        else
            System.out.println("Enrollment limit reached for course: " + title);
    }

    public String getCourseCode()
    {
        return courseCode;
    }

    public String getTitle()
    {
        return title;
    }

    public Professor getProfessor()
    {
        return professor;
    }

    public void setProfessor(Professor professor) {
        if (this.professor != null) {
            this.professor.removeCourse(this);
        }

        this.professor = professor;

        if (professor != null) {
            professor.addCourse(this);
        }
    }

    public int getCredits()
    {
        return credits;
    }

    public List<String> getPrerequisites()
    {
        return prerequisites != null ? prerequisites : Collections.emptyList();
    }

    public String getTimings()
    {
        return timings;
    }

    public int getEnrollmentLimit()
    {
        return enrollmentLimit;
    }

    @Override
    public String toString()
    {
        return courseCode + ": " + title + " by " + (professor != null ? professor.getName() : "No professor has been assigned");
    }

    public void setPrerequisites(List<String> prerequisites)
    {
        this.prerequisites = prerequisites;
    }

    public void setEnrollmentLimit(int enrollmentLimit)
    {
        this.enrollmentLimit = enrollmentLimit;
    }

    public void setCredits(int credits)
    {
        this.credits = credits;
    }

    public void setTimings(String timings)
    {
        this.timings = timings;
    }

    public void setSyllabus(String syllabus)
    {
        this.syllabus = syllabus;
    }
}