Steps to run the ERP system :

1: open project/main/erp.java
2: run erp.java

On terminal :
1: javac project/main/erp.java
2: java project/main/erp

OOPS concepts applied :

1) Inheritance : The Student, Professor, and Admin classes inherit from a common User class.

2) Encapsulation : Private data members are used in the User class, as well as other classes.

3) Polymorphism : The authenticate method is overridden in child classes to provide specific 	authentication behavior.

4) Abstraction : The User class serves as an abstract representation of a user in the system.

5) Interfaces : It has been implemented by creating Systeminterface.

General information :

1) The default assigned password to admin is 1234.

2) The default admin, user and professor are :

Default_admin@iiitd.ac.in
Default_prof@iiitd.ac.in
Default_student@iiitd.ac.in

And their password is :
1234